# SADEC - Sistema Autônomo de Drones de Entrega e Cuidado

Projeto Java (Domain Driven Design Using Java) - Global Solution 2026/2 - FIAP 1TDSPB.

## Como executar
- JDK 17 ou superior. Nenhuma biblioteca externa e nenhum banco de dados.
- IntelliJ: File > Open > pasta `SADEC`. Se `src` não estiver azul: botão direito > Mark Directory as > Sources Root.
- Rodar `src/br/com/fiap/sadec/main/Main.java` (botão ▶ ao lado do `main`).

Terminal:
```
javac -encoding UTF-8 -d out src/br/com/fiap/sadec/model/*.java src/br/com/fiap/sadec/service/*.java src/br/com/fiap/sadec/main/*.java
java -cp out br.com.fiap.sadec.main.Main
```

## Pacotes
- `br.com.fiap.sadec.model`: Local, Hospital, ZonaPouso, Filial, Drone, Rota, Entrega, TransporteOrgao, LeituraSensor
- `br.com.fiap.sadec.service`: CentralOperacao (regras de negócio)
- `br.com.fiap.sadec.main`: Main
